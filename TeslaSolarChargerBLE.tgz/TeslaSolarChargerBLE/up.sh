docker compose up -d
